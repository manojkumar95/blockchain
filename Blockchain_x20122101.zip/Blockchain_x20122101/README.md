# Blockchain_x20122101
This project helps the user to distribute the token to all the account with the help of node.js

#docker link
https://hub.docker.com/repository/docker/akashpg2515/blockchainx20122101

#docker pull
docker pull akashpg2515/blockchainx20122101:blockchain

#run the file
docker run -p 80:80 -it akashpg2515/blockchainx20122101:blockchain
